
var url = "http://loteasy.com:8080/OMS/oms1";

//var url = "http://192.168.2.46:8080";


//http://14.140.147.93:9697/