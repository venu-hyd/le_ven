var url = 'http://loteasy.com:8080/OMS'; 
var item_image_url='http://loteasy.com:8080/TEST_IMAGES/'; // Predefined url for item images.
var image_jsp_path='http://loteasy.com:8080/OMS/ajax_file.jsp';